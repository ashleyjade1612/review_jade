to store a network script
